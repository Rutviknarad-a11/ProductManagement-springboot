package com.examplerestapi.productmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examplerestapi.productmanagement.model.Pet;
import com.examplerestapi.productmanagement.repository.PetRepository;

@Service
public class PetService {
	@Autowired
	private PetRepository petrepoobj;
	
	public String addpetservice(Pet petobj) {
		
		petrepoobj.save(petobj);
		return "Added";
	}
	
	public List<Pet> fetchpet()
	{
		return (List<Pet>) petrepoobj.findAll();
	}

}
