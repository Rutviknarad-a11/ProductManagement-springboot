package com.examplerestapi.productmanagement.repository;

import org.springframework.data.repository.CrudRepository;
import com.examplerestapi.productmanagement.model.*;

public interface PetRepository extends CrudRepository<Pet, Integer> {

}
