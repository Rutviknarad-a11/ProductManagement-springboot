package com.examplerestapi.productmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examplerestapi.productmanagement.model.Pet;
import com.examplerestapi.productmanagement.service.PetService;

@RestController
@RequestMapping("/pet")
@CrossOrigin(origins = "http://localhost:3001")
public class PetController {
	@Autowired
	private PetService petserobj;
	
	@PostMapping("/addpet")
	public String addpet(@RequestBody Pet petobj) {
		
		petserobj.addpetservice(petobj);
		return "Pet Object Saved";
	}
	
	@GetMapping("/fetchdata")
	public List<Pet> fetchpet(){
		
		return petserobj.fetchpet();
	}
	

}
